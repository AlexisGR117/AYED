# Autor: Jefer Alexis Gonzalez Romero
# Fecha: 31/08/2021
from sys import stdin


def mcd(m, n):
    """
    Funcion recursiva que calcula el MCD de M y N dados
    (int, int) -> int
    """
    return m if n == 0 else mcd(n, m % n)


def main():
    print("Inserte los valores para M y N separados por un espacio:")
    m, n = list(map(int, stdin.readline().strip().split()))
    print("EL MCD de los valores dados es:", mcd(m, n))


main()
