class LinkedList:

    def __init__(self, elements=[]):
        self.head = None
        for e in elements:
            self.insert(e)

    def __str__(self):
        if self.is_empty():
            return "[]"
        else:
            return "[" + str(self.head) + "]"

    def is_empty(self):
        return self.head == None

    def insert(self, element):
        new_node = Node(element)
        if element is not None:
            if self.is_empty():
                self.head = new_node
            else:
                current = self.head
                while current.get_next() is not None:
                    current = current.get_next()
                current.set_next(new_node)

    def search(self, value):
        if self.is_empty():
            return None
        else:
            current = self.head
            while current is not None and current.get_value() != value:
                current = current.get_next()
            return current

    def invert(self):
        current = self.head
        anterior = None
        while current is not None and current.get_next() is not None:
            proximo = current.get_next()
            current.set_next(anterior)
            anterior = current
            current = proximo
        current.set_next(anterior)
        self.head = current
        return current


class Node:

    def __init__(self, value, next=None):
        self.set_value(value)
        self.set_next(next)

    def get_value(self):
        return self.value

    def get_next(self):
        return self.next

    def __str__(self):
        return '(' + str(self.value) + ')' + ((' --> ' + str(self.next)) if self.next is not None else '')

    def set_value(self, new_value):
        self.value = new_value

    def set_next(self, new_next):
        if isinstance(new_next, Node) or new_next is None:
            self.next = new_next
        else:
            raise 'Error en actualización del Nodo'


def main():
    lst = LinkedList(["cosa1", "cosa2", 3, 4, 5, True, False])
    print("Se tiene la lista enlazada simple:\n" + str(lst))
    lst.invert()
    print("Al usar la función invert se obtiene la lista donde los punteros entre los elementos están invertidos:\n" + str(lst))


main()
